import Link from "next/link";
import PageHero from "@/components/PageHero";
import SectionHeading from "@/components/SectionHeading";
import { stats, subjects } from "@/lib/data";

export const metadata = {
  title: "About Us",
  description:
    "The Achievers Institute of Learning is a Mahendranagar-based, technology-led online tuition platform for NEB Class 11 & 12, Medical (CEE) and entrance preparation.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        title="About The Achievers"
        text="A technology-led tuition platform from Mahendranagar, built so students anywhere in Nepal can learn from great teachers."
      />
      <section className="section">
        <div className="container-page grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold">Our mission</h2>
            <p className="mt-4 leading-relaxed text-slate-600">
              Students in Nepal, especially outside Kathmandu, often struggle to find consistent,
              quality teaching, structured exam practice and affordable guidance. The Achievers
              brings live classes, recorded lessons, chapterwise practice and weekly mock tests to
              your phone, so you can prepare for NEB, CEE and entrance exams from wherever you are.
            </p>
            <p className="mt-4 leading-relaxed text-slate-600">
              We offer online and physical batches, and every student can start free with a demo
              class, a mock test or a counselling session.
            </p>
            <div className="mt-6 flex gap-3">
              <Link href="/courses" className="btn-primary">Explore courses</Link>
              <Link href="/teachers" className="btn-outline">Meet the teachers</Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {stats.map((s) => (
              <div key={s.label} className="card p-6 text-center">
                <p className="font-display text-3xl font-bold text-brand-700">{s.value}</p>
                <p className="mt-1 text-sm text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-slate-50">
        <div className="container-page">
          <SectionHeading title="Subjects we teach" />
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {subjects.map((s) => (
              <span key={s} className="rounded-full bg-white px-5 py-2 text-sm font-medium text-brand-800 shadow-card">{s}</span>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
