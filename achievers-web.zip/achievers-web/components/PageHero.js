export default function PageHero({ title, text, children }) {
  return (
    <section className="bg-gradient-to-br from-brand-950 via-brand-900 to-brand-700 text-white">
      <div className="container-page py-14 sm:py-20">
        <h1 className="max-w-3xl text-3xl font-bold tracking-tight !text-white sm:text-5xl">
          {title}
        </h1>
        {text && <p className="mt-4 max-w-2xl text-base text-brand-100 sm:text-lg">{text}</p>}
        {children}
      </div>
    </section>
  );
}
