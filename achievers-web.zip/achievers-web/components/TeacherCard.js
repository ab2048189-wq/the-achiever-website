import Avatar from "./Avatar";
import { photoUrl } from "@/lib/data";

export default function TeacherCard({ teacher }) {
  return (
    <article className="card overflow-hidden">
      <Avatar
        src={photoUrl(teacher.photo)}
        name={teacher.name}
        className="aspect-[4/4] w-full"
      />
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-base font-semibold">{teacher.name}</h3>
          {teacher.featured && (
            <span className="shrink-0 rounded-full bg-accent-400/20 px-2 py-0.5 text-[11px] font-semibold text-accent-600">
              Featured
            </span>
          )}
        </div>
        <p className="mt-1 text-sm font-medium text-brand-700">{teacher.subject}</p>
        <p className="mt-1 text-sm text-slate-500">{teacher.credential}</p>
        <p className="mt-2 text-xs text-slate-400">{teacher.years}+ years experience</p>
      </div>
    </article>
  );
}
