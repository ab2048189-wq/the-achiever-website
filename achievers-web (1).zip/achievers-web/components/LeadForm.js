"use client";

import { useState } from "react";

// type: "counselling" | "contact"
export default function LeadForm({ type = "contact" }) {
  const [status, setStatus] = useState("idle"); // idle | sending | done | error
  const [error, setError] = useState("");
  const isCounselling = type === "counselling";

  async function onSubmit(e) {
    e.preventDefault();
    setStatus("sending");
    setError("");
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, ...data }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.error || "Something went wrong.");
      setStatus("done");
      form.reset();
    } catch (err) {
      setError(err.message || "Something went wrong. Please try WhatsApp or call us.");
      setStatus("error");
    }
  }

  if (status === "done") {
    return (
      <div className="card p-8 text-center" role="status">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-700">
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="mt-4 text-xl font-semibold">Thank you!</h3>
        <p className="mt-2 text-slate-600">
          We have received your request and will reply within 24 hours.
        </p>
        <button type="button" className="btn-outline mt-6" onClick={() => setStatus("idle")}>
          Send another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-5 p-6 sm:p-8" noValidate={false}>
      {/* honeypot: bots fill this, humans never see it */}
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="label">Full name</label>
          <input id="name" name="name" required minLength={2} className="input" placeholder="Your name" autoComplete="name" />
        </div>
        <div>
          <label htmlFor="phone" className="label">Phone</label>
          <input id="phone" name="phone" type="tel" required pattern="^(\+?977)?[\s-]?9[0-9]{2}[\s-]?[0-9]{7}$" title="Enter a valid Nepali mobile number" className="input" placeholder="98XXXXXXXX" autoComplete="tel" />
        </div>
      </div>

      {isCounselling ? (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="date" className="label">Preferred date</label>
              <input id="date" name="date" type="date" required className="input" />
            </div>
            <div>
              <label htmlFor="time" className="label">Preferred time</label>
              <select id="time" name="time" required className="input" defaultValue="">
                <option value="" disabled>Select a time</option>
                {Array.from({ length: 12 }, (_, i) => {
                  const h = 7 + i;
                  const label = `${h > 12 ? h - 12 : h}:00 ${h >= 12 ? "PM" : "AM"}`;
                  return <option key={h} value={label}>{label}</option>;
                })}
              </select>
            </div>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="sessionType" className="label">Session type</label>
              <select id="sessionType" name="sessionType" className="input" defaultValue="Individual">
                <option>Individual</option>
                <option>With parents</option>
                <option>Group (5+)</option>
              </select>
            </div>
            <div>
              <label htmlFor="mode" className="label">Mode</label>
              <select id="mode" name="mode" className="input" defaultValue="Online (Zoom)">
                <option>Online (Zoom)</option>
                <option>In-person</option>
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="message" className="label">What would you like to discuss?</label>
            <textarea id="message" name="message" rows={4} className="input" placeholder="Career roadmap, study strategy, admission guidance..." />
          </div>
        </>
      ) : (
        <>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="email" className="label">Email <span className="text-slate-400">(optional)</span></label>
              <input id="email" name="email" type="email" className="input" placeholder="you@example.com" autoComplete="email" />
            </div>
            <div>
              <label htmlFor="subject" className="label">Subject <span className="text-slate-400">(optional)</span></label>
              <input id="subject" name="subject" className="input" placeholder="Admission, fees, schedule..." />
            </div>
          </div>
          <div>
            <label htmlFor="message" className="label">Message</label>
            <textarea id="message" name="message" rows={5} required minLength={5} className="input" placeholder="How can we help?" />
          </div>
        </>
      )}

      <label className="flex items-start gap-2 text-xs text-slate-500">
        <input type="checkbox" name="consent" required className="mt-0.5 h-4 w-4 rounded border-slate-300" />
        <span>
          I agree that The Achievers may contact me about my request. If I am under 18, a parent or guardian is aware of this request.
        </span>
      </label>

      {status === "error" && (
        <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>
      )}

      <button type="submit" disabled={status === "sending"} className="btn-primary w-full disabled:opacity-60">
        {status === "sending" ? "Sending..." : isCounselling ? "Book free session" : "Send message"}
      </button>
    </form>
  );
}
