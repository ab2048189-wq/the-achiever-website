import Link from "next/link";
import Icon from "./Icon";
import { site, nav, payments } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="bg-brand-950 text-brand-100">
      <div className="container-page grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white font-display text-lg font-bold text-brand-700">
              A
            </span>
            <span className="font-display text-lg font-bold text-white">
              The Achievers
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-brand-200">
            {site.fullName}. Live online tuition for NEB Class 11 &amp; 12,
            Medical (CEE) and entrance preparation.
          </p>
          <div className="mt-4 flex gap-3 text-sm">
            <a className="hover:text-white" href={site.social.facebook} target="_blank" rel="noopener noreferrer">Facebook</a>
            <a className="hover:text-white" href={site.social.youtube} target="_blank" rel="noopener noreferrer">YouTube</a>
            <a className="hover:text-white" href={site.social.tiktok} target="_blank" rel="noopener noreferrer">TikTok</a>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Explore</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {nav.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="hover:text-white">{n.label}</Link>
              </li>
            ))}
            <li><Link href="/counselling" className="hover:text-white">Free Counselling</Link></li>
            <li><Link href="/faqs" className="hover:text-white">FAQs</Link></li>
            <li><Link href="/contact" className="hover:text-white">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex gap-2">
              <Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0" />
              <a href={site.mapUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white">
                {site.address}
              </a>
            </li>
            <li className="flex gap-2">
              <Icon name="call" className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                <a href={`tel:${site.phonePrimary.tel}`} className="hover:text-white">{site.phonePrimary.display}</a>
                {" · "}
                <a href={`tel:${site.phoneSecondary.tel}`} className="hover:text-white">{site.phoneSecondary.display}</a>
              </span>
            </li>
            <li className="flex gap-2">
              <Icon name="mail" className="mt-0.5 h-4 w-4 shrink-0" />
              <a href={`mailto:${site.email}`} className="break-all hover:text-white">{site.email}</a>
            </li>
            <li className="flex gap-2">
              <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{site.hours}</span>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-white">Get the app</h3>
          <a
            href={site.playStore}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex rounded-xl border border-white/20 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10"
          >
            Get it on Google Play
          </a>
          <p className="mt-2 text-xs text-brand-300">iOS app coming soon.</p>

          <h3 className="mt-6 text-sm font-semibold uppercase tracking-wide text-white">We accept</h3>
          <div className="mt-3 flex items-center gap-2">
            {payments.map((p) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                key={p.name}
                src={p.src}
                alt={p.name}
                loading="lazy"
                className="h-7 rounded bg-white px-2 py-1"
              />
            ))}
          </div>
          <p className="mt-2 text-xs text-brand-300">Bank transfer also accepted.</p>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-page flex flex-col items-center justify-between gap-2 py-5 text-xs text-brand-300 sm:flex-row">
          <p>© {new Date().getFullYear()} The Achievers. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-white">Privacy</Link>
            <Link href="/terms" className="hover:text-white">Terms</Link>
            <Link href="/cookies" className="hover:text-white">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
