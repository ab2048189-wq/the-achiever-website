"use client";

import Link from "next/link";
import { useState } from "react";
import Icon from "./Icon";
import { nav, appLinks, site } from "@/lib/data";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur">
      <div className="hidden bg-brand-950 text-xs text-brand-100 sm:block">
        <div className="container-page flex items-center justify-between py-1.5">
          <span>{site.tagline}</span>
          <a href={`tel:${site.phonePrimary.tel}`} className="hover:text-white">
            Call {site.phonePrimary.display}
          </a>
        </div>
      </div>

      <div className="container-page flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 font-display text-lg font-bold text-white">
            A
          </span>
          <span className="font-display text-lg font-bold text-brand-950">
            The Achievers
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-brand-50 hover:text-brand-700"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <a href={appLinks.login} className="btn-outline !py-2">
            Sign in
          </a>
          <a href={appLinks.register} className="btn-primary !py-2">
            Enroll
          </a>
        </div>

        <button
          type="button"
          className="rounded-lg p-2 text-brand-900 hover:bg-brand-50 lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name={open ? "close" : "menu"} />
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-100 bg-white lg:hidden">
          <nav className="container-page flex flex-col py-3" aria-label="Mobile">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-base font-medium text-slate-700 hover:bg-brand-50"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/counselling"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-base font-medium text-slate-700 hover:bg-brand-50"
            >
              Free Counselling
            </Link>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a href={appLinks.login} className="btn-outline">
                Sign in
              </a>
              <a href={appLinks.register} className="btn-primary">
                Enroll
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
