// Native <details> keeps this a server component and works without JS.
export default function FAQList({ items }) {
  return (
    <div className="divide-y divide-slate-100 rounded-2xl border border-slate-100 bg-white shadow-card">
      {items.map((f) => (
        <details key={f.q} className="group p-5">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-left font-semibold text-brand-950">
            {f.q}
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 text-brand-600 transition group-open:rotate-180" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M19 9l-7 7-7-7" />
            </svg>
          </summary>
          <p className="mt-3 text-slate-600">{f.a}</p>
        </details>
      ))}
    </div>
  );
}
