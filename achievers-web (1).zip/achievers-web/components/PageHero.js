import { heroImages } from "@/lib/data";

// Photo background with a brand-colour overlay. If the image fails to load, the gradient still reads well.
export default function PageHero({ title, text, children, image = heroImages.page }) {
  return (
    <section className="relative isolate overflow-hidden bg-gradient-to-br from-brand-950 via-brand-900 to-brand-700 text-white">
      {image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={image}
          alt=""
          loading="eager"
          fetchPriority="high"
          className="absolute inset-0 -z-10 h-full w-full object-cover opacity-25 mix-blend-luminosity"
        />
      )}
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-brand-950/90 via-brand-900/70 to-transparent" />
      <div className="container-page py-14 sm:py-20">
        <h1 className="max-w-3xl text-3xl font-bold tracking-tight !text-white sm:text-5xl">
          {title}
        </h1>
        {text && <p className="mt-4 max-w-2xl text-base text-brand-100 sm:text-lg">{text}</p>}
        {children}
      </div>
    </section>
  );
}
