import Link from "next/link";
import Icon from "./Icon";

export default function CourseCard({ course }) {
  return (
    <article className="card flex flex-col overflow-hidden">
      <div className="relative aspect-[16/9] bg-gradient-to-br from-brand-600 to-brand-900">
        {course.image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={course.image}
            alt=""
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        <span className="absolute left-3 top-3 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-brand-800">
          {course.level}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-lg font-semibold">{course.title}</h3>
        <p className="mt-2 text-sm text-slate-600">{course.short}</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {course.mode.map((m) => (
            <span key={m} className="rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-medium text-brand-700">
              {m}
            </span>
          ))}
        </div>
        <p className="mt-3 text-xs text-slate-500">{course.subjects.join(" · ")}</p>
        <div className="mt-auto flex items-center justify-between pt-5">
          <span className="text-sm font-semibold text-slate-900">
            {course.price ? `Rs. ${course.price}` : "Fee on enquiry"}
          </span>
          <Link
            href={`/courses/${course.slug}`}
            className="inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:text-brand-900"
          >
            View details <Icon name="arrow" className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </article>
  );
}
