export default function SectionHeading({ eyebrow, title, text, center = true }) {
  return (
    <div className={`mx-auto max-w-2xl ${center ? "text-center" : "mx-0 text-left"}`}>
      {eyebrow && (
        <p className="text-sm font-semibold uppercase tracking-wider text-brand-600">
          {eyebrow}
        </p>
      )}
      <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
      {text && <p className="mt-3 text-base text-slate-600 sm:text-lg">{text}</p>}
    </div>
  );
}
