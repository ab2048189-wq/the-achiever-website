import PageHero from "@/components/PageHero";

export const metadata = {
  title: "Cookies Policy",
  alternates: { canonical: "/cookies" },
};

// TEMPLATE ONLY: update to match the analytics/tools you actually add.
export default function CookiesPage() {
  return (
    <>
      <PageHero title="Cookies Policy" />
      <section className="section">
        <div className="container-page prose-legal max-w-3xl">
          <p>
            Cookies are small files stored on your device. This website uses only what is needed to work properly.
          </p>
          <h2>Essential cookies</h2>
          <p>Used for security and basic site function.</p>
          <h2>Embedded content</h2>
          <p>
            Demo videos are embedded from YouTube (privacy-enhanced mode). YouTube may set its own cookies when you play a video.
          </p>
          <h2>Analytics</h2>
          <p>
            If we add analytics, we will list it here and ask for your consent where required.
          </p>
        </div>
      </section>
    </>
  );
}
