import PageHero from "@/components/PageHero";
import LeadForm from "@/components/LeadForm";
import Icon from "@/components/Icon";
import { site } from "@/lib/data";

export const metadata = {
  title: "Free Counselling",
  description:
    "Book a free 1-on-1 counselling session: career roadmap, study strategy, scholarship and admission guidance.",
  alternates: { canonical: "/counselling" },
};

const outcomes = [
  "Career roadmap for Science, Management or Medical",
  "A study strategy that fits your exam dates",
  "Scholarship and admission guidance",
];

export default function CounsellingPage() {
  return (
    <>
      <PageHero
        title="Free 1-on-1 counselling"
        text="Talk to a counsellor about your goals. Students, parents and groups are all welcome."
      />
      <section className="section">
        <div className="container-page grid gap-10 lg:grid-cols-5">
          <div className="space-y-6 lg:col-span-2">
            <h2 className="text-2xl font-bold">What you will leave with</h2>
            <ul className="space-y-3">
              {outcomes.map((o) => (
                <li key={o} className="flex gap-3">
                  <Icon name="check" className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
            <div className="rounded-2xl bg-brand-50 p-5 text-sm text-slate-600">
              <p><span className="font-semibold text-brand-950">Hours:</span> {site.hours}</p>
              <p className="mt-2">We reply within 24 hours.</p>
              <p className="mt-2">
                Prefer to call?{" "}
                <a href={`tel:${site.phonePrimary.tel}`} className="font-semibold text-brand-700 hover:underline">
                  {site.phonePrimary.display}
                </a>
              </p>
            </div>
          </div>
          <div className="lg:col-span-3">
            <LeadForm type="counselling" />
          </div>
        </div>
      </section>
    </>
  );
}
