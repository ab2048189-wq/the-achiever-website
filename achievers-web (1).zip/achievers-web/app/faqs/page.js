import PageHero from "@/components/PageHero";
import FAQList from "@/components/FAQList";
import { faqs } from "@/lib/data";

export const metadata = {
  title: "FAQs",
  description: "Answers about classes, mock tests, payments, the app and counselling at The Achievers.",
  alternates: { canonical: "/faqs" },
};

export default function FaqsPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <PageHero title="Frequently asked questions" />
      <section className="section">
        <div className="container-page max-w-3xl">
          <FAQList items={faqs} />
        </div>
      </section>
    </>
  );
}
