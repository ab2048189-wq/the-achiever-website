import PageHero from "@/components/PageHero";
import { site } from "@/lib/data";

export const metadata = {
  title: "Terms & Conditions",
  alternates: { canonical: "/terms" },
};

// TEMPLATE ONLY: add the real refund/cancellation policy (PRD C4) and have a lawyer review.
export default function TermsPage() {
  return (
    <>
      <PageHero title="Terms & Conditions" />
      <section className="section">
        <div className="container-page prose-legal max-w-3xl">
          <p>By using this website and our services you agree to the following terms.</p>
          <h2>Use of content</h2>
          <p>
            Classes, notes, recordings and tests are for the enrolled student&apos;s personal use only.
            Copying, sharing or reselling them is not allowed.
          </p>
          <h2>Accounts</h2>
          <p>Keep your login private. One account is for one student.</p>
          <h2>Fees and payments</h2>
          <p>
            Fees are shown on the course page or confirmed by our team. We accept eSewa, Khalti, Fonepay and bank transfer.
          </p>
          <h2>Refunds and cancellation</h2>
          <p>
            {/* TODO: insert the actual refund and cancellation policy. */}
            Our refund and cancellation policy will be stated here and on each course page.
          </p>
          <h2>Contact</h2>
          <p>
            <a href={`mailto:${site.email}`} className="text-brand-700 underline">{site.email}</a>
          </p>
        </div>
      </section>
    </>
  );
}
