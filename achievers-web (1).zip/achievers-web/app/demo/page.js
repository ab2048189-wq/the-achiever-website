import Link from "next/link";
import PageHero from "@/components/PageHero";
import { demoVideos, heroImages, site } from "@/lib/data";

export const metadata = {
  title: "Free Demo Class",
  description: "Watch free demo classes from The Achievers before you enroll.",
  alternates: { canonical: "/demo" },
};

export default function DemoPage() {
  return (
    <>
      <PageHero image={heroImages.demo} title="Free demo classes" text="See how our teachers explain concepts, then decide." />
      <section className="section">
        <div className="container-page">
          <div className="grid gap-8 md:grid-cols-2">
            {demoVideos.map((v) => (
              <div key={v.id} className="card overflow-hidden">
                <div className="aspect-video bg-black">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${v.id}`}
                    title={v.title}
                    loading="lazy"
                    allow="accelerometer; encrypted-media; picture-in-picture"
                    allowFullScreen
                    className="h-full w-full"
                  />
                </div>
                <div className="p-4 font-semibold text-brand-950">{v.title}</div>
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-3xl bg-brand-50 p-8 text-center">
            <h2 className="text-2xl font-bold">Liked what you saw?</h2>
            <p className="mt-2 text-slate-600">Test yourself with a free mock test, or watch more on our YouTube channel.</p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href="/tests/free" className="btn-primary">Take free mock test</Link>
              <a href={site.social.youtube} target="_blank" rel="noopener noreferrer" className="btn-outline">YouTube channel</a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
