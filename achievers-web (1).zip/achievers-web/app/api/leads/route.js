import { NextResponse } from "next/server";

// Simple in-memory rate limit (per server instance). Use Redis / Cloudflare in production (TRD 5.6).
const hits = new Map();
const WINDOW_MS = 60_000;
const MAX_HITS = 5;

function limited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length > MAX_HITS;
}

const clean = (v, max = 1000) =>
  typeof v === "string" ? v.trim().slice(0, max) : "";

export async function POST(request) {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (limited(ip)) {
    return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  // Honeypot: pretend success so bots don't retry
  if (clean(body.website)) return NextResponse.json({ ok: true });

  const type = body.type === "counselling" ? "counselling" : "contact";
  const lead = {
    type,
    name: clean(body.name, 100),
    phone: clean(body.phone, 20),
    email: clean(body.email, 120),
    subject: clean(body.subject, 150),
    message: clean(body.message, 2000),
    date: clean(body.date, 20),
    time: clean(body.time, 20),
    sessionType: clean(body.sessionType, 40),
    mode: clean(body.mode, 40),
    consent: body.consent === "on" || body.consent === true,
    createdAt: new Date().toISOString(),
  };

  if (lead.name.length < 2) {
    return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  }
  if (!/^(\+?977)?[\s-]?9\d{2}[\s-]?\d{7}$/.test(lead.phone)) {
    return NextResponse.json({ error: "Please enter a valid Nepali mobile number." }, { status: 400 });
  }
  if (lead.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email)) {
    return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  }
  if (type === "contact" && lead.message.length < 5) {
    return NextResponse.json({ error: "Please enter a message." }, { status: 400 });
  }
  if (type === "counselling" && (!lead.date || !lead.time)) {
    return NextResponse.json({ error: "Please choose a date and time." }, { status: 400 });
  }
  if (!lead.consent) {
    return NextResponse.json({ error: "Please accept the consent checkbox." }, { status: 400 });
  }

  const webhook = process.env.LEADS_WEBHOOK_URL;
  if (webhook) {
    try {
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(lead),
      });
      if (!res.ok) throw new Error(`Webhook ${res.status}`);
    } catch (err) {
      console.error("Lead webhook failed:", err);
      return NextResponse.json(
        { error: "We could not save your request. Please contact us on WhatsApp." },
        { status: 502 }
      );
    }
  } else {
    // No webhook configured: log so nothing is silently lost during development.
    console.log("[lead]", lead);
  }

  return NextResponse.json({ ok: true });
}
