import Link from "next/link";
import { notFound } from "next/navigation";
import PageHero from "@/components/PageHero";
import { syllabusTracks, whatsappLink } from "@/lib/data";

export function generateStaticParams() {
  return syllabusTracks.map((t) => ({ track: t.slug }));
}

export function generateMetadata({ params }) {
  const t = syllabusTracks.find((s) => s.slug === params.track);
  if (!t) return {};
  return {
    title: `${t.title} Syllabus`,
    description: `Syllabus for ${t.title} at The Achievers.`,
    alternates: { canonical: `/syllabus/${t.slug}` },
  };
}

export default function SyllabusTrackPage({ params }) {
  const t = syllabusTracks.find((s) => s.slug === params.track);
  if (!t) notFound();

  return (
    <>
      <PageHero title={`${t.title} Syllabus`} text={t.note} />
      <section className="section">
        <div className="container-page max-w-3xl">
          {/* TODO: Render chapters + weightage from CMS/API (PRD M4) and offer a PDF download. */}
          <div className="card p-8 text-center">
            <h2 className="text-xl font-semibold">Chapter list coming soon</h2>
            <p className="mt-2 text-slate-600">
              The detailed chapter-wise syllabus and weightage for this track will appear here.
              Need it now? Ask our team and we will send it to you.
            </p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="btn-primary">Ask on WhatsApp</a>
              <Link href="/syllabus" className="btn-outline">All tracks</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
