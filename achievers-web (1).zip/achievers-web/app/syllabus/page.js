import Link from "next/link";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";
import { syllabusTracks } from "@/lib/data";

export const metadata = {
  title: "Syllabus",
  description: "Syllabus for NEB Class 11 & 12, CEE Medical, IOE, BSc.CSIT and IOE MSc entrance preparation.",
  alternates: { canonical: "/syllabus" },
};

export default function SyllabusPage() {
  return (
    <>
      <PageHero title="Syllabus" text="Chapter lists and weightage for every track we teach." />
      <section className="section">
        <div className="container-page grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {syllabusTracks.map((t) => (
            <Link key={t.slug} href={`/syllabus/${t.slug}`} className="card group p-6 transition hover:-translate-y-0.5">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                <Icon name="book" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{t.title}</h3>
              <p className="mt-1 text-sm text-slate-600">{t.note}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-700">
                View <Icon name="arrow" className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
