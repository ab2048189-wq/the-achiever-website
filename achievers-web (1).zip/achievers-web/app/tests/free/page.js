import Link from "next/link";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";
import { appLinks } from "@/lib/data";

export const metadata = {
  title: "Free Mock Test",
  description:
    "Take a free computer-based mock test (IOE/CSIT style) with instant result, solutions, percentile rank and subject analysis.",
  alternates: { canonical: "/tests/free" },
};

const perks = [
  "Real CBT exam interface with timer and question palette",
  "Instant score and detailed solutions",
  "Percentile rank against other students",
  "Subject-wise analysis to find weak topics",
  "Chapterwise practice sets, untimed with explanations",
];

export default function FreeTestPage() {
  return (
    <>
      <PageHero
        title="Free mock test"
        text="Find out where you stand today. Sign up with phone, Google or email and start in minutes."
      >
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a href={appLinks.freeTest} className="btn-accent">Start free mock test</a>
          <a href={appLinks.register} className="btn-ghost-light">Create free account</a>
        </div>
      </PageHero>

      <section className="section">
        <div className="container-page grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold">What you get</h2>
            <ul className="mt-6 space-y-4">
              {perks.map((p) => (
                <li key={p} className="flex gap-3">
                  <Icon name="check" className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="card p-8">
            <h2 className="text-2xl font-bold">How it works</h2>
            <ol className="mt-6 space-y-5">
              {["Create a free account", "Pick a mock test", "Attempt it in exam mode", "Review your result and solutions"].map((s, i) => (
                <li key={s} className="flex items-center gap-4">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-600 font-display font-bold text-white">{i + 1}</span>
                  <span className="font-medium text-brand-950">{s}</span>
                </li>
              ))}
            </ol>
            <p className="mt-6 text-sm text-slate-500">
              Want guidance on what to study next?{" "}
              <Link href="/counselling" className="font-semibold text-brand-700 hover:underline">Book free counselling</Link>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
