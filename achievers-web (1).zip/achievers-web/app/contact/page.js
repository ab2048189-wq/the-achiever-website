import PageHero from "@/components/PageHero";
import LeadForm from "@/components/LeadForm";
import Icon from "@/components/Icon";
import { site, whatsappLink } from "@/lib/data";

export const metadata = {
  title: "Contact",
  description: "Contact The Achievers Institute of Learning, Mahendranagar. Call, WhatsApp, email or send a message.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  const items = [
    { icon: "pin", label: "Address", node: <a href={site.mapUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">{site.address}</a> },
    {
      icon: "call",
      label: "Phone",
      node: (
        <>
          <a href={`tel:${site.phonePrimary.tel}`} className="hover:underline">{site.phonePrimary.display}</a>
          {" · "}
          <a href={`tel:${site.phoneSecondary.tel}`} className="hover:underline">{site.phoneSecondary.display}</a>
        </>
      ),
    },
    { icon: "mail", label: "Email", node: <a href={`mailto:${site.email}`} className="break-all hover:underline">{site.email}</a> },
    { icon: "clock", label: "Hours", node: site.hours },
  ];

  return (
    <>
      <PageHero title="Contact us" text="Questions about courses, fees or schedules? We reply within 24 hours." />
      <section className="section">
        <div className="container-page grid gap-10 lg:grid-cols-5">
          <div className="space-y-6 lg:col-span-2">
            {items.map((i) => (
              <div key={i.label} className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                  <Icon name={i.icon} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-brand-950">{i.label}</p>
                  <p className="text-sm text-slate-600">{i.node}</p>
                </div>
              </div>
            ))}
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="btn w-full bg-[#25D366] text-white hover:brightness-95">
              Chat on WhatsApp
            </a>
          </div>
          <div className="lg:col-span-3">
            <LeadForm type="contact" />
          </div>
        </div>
      </section>
    </>
  );
}
