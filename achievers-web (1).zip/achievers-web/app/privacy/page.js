import PageHero from "@/components/PageHero";
import { site } from "@/lib/data";

export const metadata = {
  title: "Privacy Policy",
  alternates: { canonical: "/privacy" },
};

// TEMPLATE ONLY: have the business and a lawyer review before publishing.
export default function PrivacyPage() {
  return (
    <>
      <PageHero title="Privacy Policy" />
      <section className="section">
        <div className="container-page prose-legal max-w-3xl">
          <p>
            This page explains what information {site.fullName} collects, why, and the choices you have.
            Many of our students are under 18, so we collect only what we need.
          </p>
          <h2>Information we collect</h2>
          <ul>
            <li>Contact details you submit: name, phone, email (optional) and your message.</li>
            <li>Counselling requests: preferred date, time, session type and topic.</li>
            <li>Account and learning data on our platform: class, course, test attempts and progress.</li>
          </ul>
          <h2>How we use it</h2>
          <ul>
            <li>To reply to your enquiry and provide counselling.</li>
            <li>To run classes, tests and show your progress.</li>
            <li>To improve our courses and website.</li>
          </ul>
          <h2>Minors</h2>
          <p>
            If you are under 18, please involve a parent or guardian when sharing personal information with us.
          </p>
          <h2>Sharing and retention</h2>
          <p>
            We do not sell personal information. We keep it only as long as needed for the purposes above
            and delete it on request where possible.
          </p>
          <h2>Contact</h2>
          <p>
            Questions or deletion requests: <a href={`mailto:${site.email}`} className="text-brand-700 underline">{site.email}</a>.
          </p>
        </div>
      </section>
    </>
  );
}
